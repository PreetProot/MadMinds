﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerRadius : MonoBehaviour
{
    void OnTriggerEnter (Collider other)
    {
        Debug.Log("Detected");
    }

    void OnTriggerStay(Collider other)
    {
        Debug.Log("Inside");
    }

    void OnTriggerExit(Collider other)
    {
        Debug.Log("Exited");
    }
}
